In Linux, I downloaded clion, save the file, and extracted the file via firefox. I then typed the command 
cd Downloads and then cd-2020.3.2 in the terminal. I went to the downloaded folder, went to bin, and
clicked on clion.sh. The clion program will then open up. I created a new project and added
fork-join.c, rendevous.c, barrier.c, and common_threads.h. The cmake file is added automatically when you
make a new project and adjusts when new files are added to the project. You then run the project in the run 
tab.  
